package com.wanbo.hdmi2;

import android.app.Activity;
import android.os.Bundle;
import android.content.ComponentName;
import android.content.Intent;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String PROJECTIVY = "com.spocky.projengmenu";

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        switchToHdmi2();
    }

    private void switchToHdmi2() {
        // Projectivy Launcher 4.x exposes this explicit HDMI2 activity.
        Intent hdmi2 = new Intent(Intent.ACTION_MAIN);
        hdmi2.setComponent(new ComponentName(
            PROJECTIVY,
            "com.spocky.projengmenu.ui.guidedActions.activities.input.SourceHDMI2Activity"
        ));
        hdmi2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(hdmi2);
            finish();
            return;
        } catch (Exception ignored) {}

        // Fallback: open Projectivy input-source popup if HDMI2 is not
        // exposed by the projector's Android input framework.
        Intent popup = new Intent(Intent.ACTION_MAIN);
        popup.setComponent(new ComponentName(
            PROJECTIVY,
            "com.spocky.projengmenu.ui.guidedActions.activities.input.SourcePopupActivity"
        ));
        popup.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(popup);
        } catch (Exception e) {
            Toast.makeText(this,
                "Wanbo HDMI2 kaynağı Android'a açık değil.",
                Toast.LENGTH_LONG).show();
        }
        finish();
    }
}
