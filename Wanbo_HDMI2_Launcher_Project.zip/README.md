# Wanbo HDMI 2 Launcher

Bu uygulama tek amaçlıdır: açıldığı anda Projectivy Launcher 4.x içindeki
SourceHDMI2Activity'yi çağırır.

Hedef cihaz:
- Wanbo WPB84
- Android TV 11
- Projectivy Launcher 4.71

ÖNEMLİ:
Projectivy'nin HDMI2 Activity'si mevcut olsa da Projectivy'nin HDMI kaynaklarını
gösterebilmesi Android TV Input Framework / cihaz üreticisinin giriş API'sine bağlıdır.
Wanbo WPB84 HDMI2'yi standart API üzerinden açmıyorsa bu uygulama da donanımsal
olarak HDMI2'ye geçemez. Bu durumda uygulama Projectivy'nin Source Popup ekranına
geri düşer.

Derleme:
1. Android Studio ile bu klasörü aç.
2. Gradle Sync yap.
3. Build > Build APK(s).
